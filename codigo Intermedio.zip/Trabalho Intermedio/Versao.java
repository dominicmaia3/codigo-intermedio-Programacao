public class Versao {
    /*Cada versão é caracterizada pela unidade, valor alfa e valor beta (atributos numéricos) */
}
