public class Equipamento {
    /*[ R24 ] A aplicação deve permitir introduzir e gerir equipamentos de hardware.
Os equipamentos de hardware são caracterizados por uma marca, modelo, código interno, série, versão,
voltagem, quantidade em stock, preço de venda, observações e se o equipamento é OEM (Original
Equipment Manufacturer).*/

}
