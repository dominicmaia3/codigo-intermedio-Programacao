public class Categoria {
    /*Cada categoria é caracterizada pela sua designação e família (atributos alfanuméricos). */
    
}
