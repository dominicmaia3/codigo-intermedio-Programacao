public class ServicoCompra {
    
}
