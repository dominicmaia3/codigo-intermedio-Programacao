public class Serie {
   /*[ R30 ] Cada série possui uma geração e sequência (atributos numéricos). */ 
}
