public class Fornecedor {
    /*[ R27 ] Cada fornecedor é caracterizado por nome, morada e contacto telefónico */
}
