import java.util.ArrayList;

public class ServicoCompra { //isa
    private Utilizador tecnico;
   private ArrayList<Equipamento> listaProdutos;
   private Date dataPedido;
   private String descricao;
   private String[] estado;
   private int tempoProcessamento;
   private float valorTotal;
   private int codigo;
   private static int contadorCodigo = 0;

   public ServicoCompra(Utilizador var1, ArrayList<Equipamento> var2, Date var3, String var4, String[] var5, int var6, float var7, int var8) {
      this.tecnico = var1;
      this.listaProdutos = var2;
      this.dataPedido = var3;
      this.descricao = var4;
      this.estado = var5;
      this.tempoProcessamento = var6;
      this.valorTotal = var7;
      this.codigo = var8;
   }
   
}
