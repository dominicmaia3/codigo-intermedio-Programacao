import java.util.ArrayList;
import java.util.List;

public class Equipamento {
/*[ R24 ] A aplicação deve permitir introduzir e gerir equipamentos de hardware.
Os equipamentos de hardware são caracterizados por uma marca, modelo, código interno, série, versão,
voltagem, quantidade em stock, preço de venda, observações e se o equipamento é OEM (Original
Equipment Manufacturer).*/

    private String marca;
    private String modelo;
    private int codigoInterno; //deve ser unico, ou seja nao vai ter setter
    private Serie serie; 
    private Versao versao;
    private float voltagem;
    private int quantidadeStock;
    private float precoVenda; 
    private String observacoes;
    private boolean seraOEM; //1/verdadeiro se o equipamento é OEM (Original Equipment Manufacturer)
    private List<Fornecedor> fornecedores; //Cada equipamento tem associado uma lista até 6 fornecedores
    private List<Categoria> categorias;
    //private int stock;

    //construtor
    public Equipamento(String marca, String modelo, int codigoInterno, Serie serie, Versao versao, float voltagem, int quantidadeStock, float precoVenda, String observacoes, boolean seraOEM){
       
        
        this.marca=marca;
        this.modelo=modelo;
        this.codigoInterno=codigoInterno;
        this.serie=serie;
        this.versao=versao;
        this.voltagem=voltagem;
        this.quantidadeStock=quantidadeStock;
        this.precoVenda=precoVenda;
        this.observacoes=observacoes;
        this.seraOEM=seraOEM;
        this.fornecedores=new ArrayList<>();// Array??
        this.categorias=new ArrayList<>();//???
    
    }

    //metodo getter e setter 
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }


    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }


    public int getCodigoInterno() { //por ser unico nao tem setter
        return codigoInterno;
    }


    public Serie getSerie() {
        return serie;
    }

    public void setSerie(Serie serie) {
        this.serie = serie;
    }


    public Versao getVersao() {
        return versao;
    }

    public void setVersao(Versao versao) {
        this.versao = versao;
    }


    public float getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(float voltagem) {
        this.voltagem = voltagem;
    }


    public int getQuantidadeStock() {
        return quantidadeStock;
    }

    public void setQuantidadeStock(int quantidadeStock) {
        this.quantidadeStock = quantidadeStock;
    }


    public float getPrecoVenda() {
        return precoVenda;
    }

    public void setPrecoVenda(float precoVenda) {
        this.precoVenda = precoVenda;
    }


    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }


    public boolean getSeraOEM() {
        return seraOEM;
    }

    public void setSeraOEM(boolean seraOEM) {
        this.seraOEM = seraOEM;
    }



    public List<Fornecedor> getFornecedores() {
        return fornecedores;
    }


    public boolean adicionarFornecedor(Fornecedor fornecedor) {
        if (fornecedores.size() <= 6) { // Verifica se o limite de 6 fornecedores ainda não foi atingido
            fornecedores.add(fornecedor); //se nao foi vai adicionar um fornecedor 
            return true; // fornecedor adicionado
        } else {
            return false; // fornecedor não adicionado
        }
    }

    public boolean adicionarCategoria(Categoria categoria) {
        if (categorias.size() <= 4) { // Verifica se o limite de 6 fornecedores ainda não foi atingido
            categorias.add(categoria); // se nao for vai adcionar uma categoria 
            return true; // categoria adicionada
        } else {
            return false; // categoria não adicionado
        }
    }

}
