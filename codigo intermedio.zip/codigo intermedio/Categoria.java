public class Categoria {//isa
    /*Cada categoria é caracterizada pela sua designação e família (atributos alfanuméricos). */
    //indefinido
    private String designacao;
    private String familia;

    public Categoria(String designacao, String familia){
        this.designacao= designacao;
        this.familia= familia;
    }
    
    public String getDesignacao(){
        return designacao;
       }

    public String getFamilia(){
        return familia;
       }
}
