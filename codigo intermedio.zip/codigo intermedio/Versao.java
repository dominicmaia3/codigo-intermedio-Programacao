public class Versao {//isa
    /*Cada versão é caracterizada pela unidade, valor alfa e valor beta (atributos numéricos) */
    private int unidade;
    private int valorAlfa;
    private int valorBeta; 
    
    public Versao (int unidade, int valorAlfa, int valorBeta){

        this.unidade= unidade;
        this.valorAlfa = valorAlfa;
        this.valorBeta = valorBeta;

    }

    public int getUnidade (){
        return unidade;
    }

    public int getValorAlfa (){
        return valorAlfa;
    }

    public int getValorBeta (){
        return valorBeta;
    }

}
