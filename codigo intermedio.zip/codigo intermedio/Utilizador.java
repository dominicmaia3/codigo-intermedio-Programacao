
public class Utilizador{

    private String username;
    private String password;
    private String nome;
    private String email;
    private boolean estado; //true/1 ativo, false/0 inativo
    private String tipo; //admnistrador, tecnico, cliente ?????????

    
    //construtor:
    public Utilizador(String username, String password, String nome, String email, boolean estado, String tipo){
        this.username=username;
        this.password=password;
        this.nome=nome;
        this.email=email;
        this.estado=estado;
        this.tipo=tipo;

    }

    //métodos getters e setters para username, password, nome, email, estado, 
    public String getUsername(){
        return username;
    }

    public void setUsername(String username){
        this.username=username;
    }

    public String getPassword(){
        return password;
    }

    public void setPassword (String password){
        this.password=password;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome=nome;
    }

    public String getEmail(){
        return email;
    }

    public void setEmail (String email){
        this.email=email;
    }

    public boolean getEstado(){
        return estado;
    }

    public void setEstado (boolean estado){
        this.estado=estado;
    }

    
    public String getTipo(){
        return tipo;
    }

    public void setTipo(String tipo){
        this.tipo=tipo;
    }

   
}

