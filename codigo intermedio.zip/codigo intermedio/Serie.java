public class Serie { //isa
   /*[ R30 ] Cada série possui uma geração e sequência (atributos numéricos). */ 
   private int geracao;
   private int sequencia;

   public Serie (int geracao, int sequencia){
      this.geracao = geracao;
      this.sequencia = sequencia;
   }

   public int getGeracao(){
      return geracao;
     }

   public int getSequencia(){
      return sequencia;
     }
}
