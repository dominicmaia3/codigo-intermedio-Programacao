public class Fornecedor {
    /*[ R27 ] Cada fornecedor é caracterizado por nome, morada e contacto telefónico */
//fdomi
    private String nome;
    private String morada;
    private String contactoTelefonico;

    //construtor
    public Fornecedor(String nome, String morada, String contactoTelefonico){
        this.nome=nome;
        this.morada=morada;
        this.contactoTelefonico=contactoTelefonico;
    }

    //metodos getters e setters:
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getContactoTelefonico() {
        return contactoTelefonico;
    }

    public void setContatoTelefonico(String contactoTelefonico) {
        this.contactoTelefonico = contactoTelefonico;
    }

}
